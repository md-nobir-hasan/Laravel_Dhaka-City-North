

    
    <?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-5 align-self-center">
                    <h6 class="title_page" class="page-title">ওয়ার্ডের দায়িত্বভার ব্যক্তির তথ্য যোগ করুন</h6>
                </div>
              
                <div class="col-7 align-self-center">
                    <div class="d-flex align-items-center justify-content-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="#">হোম</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">থানার দায়িত্বভার ব্যক্তির তথ্য</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        
      <?php if(session()->has('message')): ?>
      <?php if(session()->get('message')=='0'): ?>
          <div class="alert alert-danger">
              <p>আপনার দেওয়া তথ্য বিদ্যমান আছে</p>

          </div>
      <?php elseif(session()->get('message')=='4'): ?>
          <div class="alert alert-success">
              <p>সফলভাবে ডিলেট হয়েছে</p>

          </div>
      <?php elseif(session()->get('message')=='1'): ?>
          <div class="alert alert-success">
              <p>সফলভাবে যোগ করা হয়েছে</p>

          </div>
      <?php elseif(session()->get('message')=='5'): ?>
          <div class="alert alert-success">
              <p>সফলভাবে আপডেট হয়েছে</p>

          </div>
      <?php endif; ?>
  <?php endif; ?>

  <?php if($errors->any()): ?>
  <div class="alert alert-danger">
      <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
              <?php echo e($error); ?>

          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
  </div>
  <?php endif; ?>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
    
            <div id="project" class="tabcontent">
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Add Word -->
                <div class="col-12 w-75 m-auto">
                    <div class="card">
                        <div class="card-body">
                            <!-- <h2 class="card-title text-center" style="text-transform: uppercase;">Add Police Station</h2>-->
                            <form action="/insert_word_rp_info" method="POST" class="form-horizontal form-material mx-2" enctype="multipart/form-data">
                               <?php echo csrf_field(); ?>
                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">আসন </label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <select id="p_id" name="p_id" class="form-select shadow-none form-control-line" onchange="data_fetch()">
                                            <option value="">সিলেক্ট আসন </option>
                                            <?php $__currentLoopData = $data_p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name.'-'.$value->no); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">থানা</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <select id="ps_id" name="ps_id" class="form-select shadow-none form-control-line" onchange="ps_func()">
                                            <option value="">সিলেক্ট থানা</option>
                                            
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">ওয়ার্ড</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <select id="w_id" name="w_id" class="form-select shadow-none form-control-line">
                                            <option value="">সিলেক্ট ওয়ার্ড</option>
                                            
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">পদবি</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <select name="d_id" class="form-select shadow-none form-control-line">
                                            <option value="">সিলেক্ট পদবি</option>
                                            <?php $__currentLoopData = $data_designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->d_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;"> নাম</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <input name='rp_name' type="text" placeholder="নাম" class="form-control form-control-line">
                                    </div>
                                </div>
                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;"> মোবাইল নম্বর</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <input name='rp_phone' type="text" placeholder="মোবাইল নম্বর" class="form-control form-control-line">
                                    </div>
                                </div>
                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">  ভোটার নং</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <input name='rp_nid' type="text" placeholder="ভোটার নং" class="form-control form-control-line">
                                    </div>
                                </div>

                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">ই-মেইল</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <input name='rp_email' type="email" placeholder="ই-মেইল" class="form-control form-control-line">
                                    </div>
                                </div>
        
                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">জন্ম তারিখ</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <input name='rp_dob' type="date" lang="bn"  class="form-control form-control-line">
                                    </div>
                                </div>
        
                                <div class="form-group d-flex">
                                    <label class="col-sm-12" style="width: 25%;">ছবি</label>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <input name='rp_img' type="file" placeholder="ছবি" class="form-control form-control-line">
                                    </div>
                                </div>

                                <div class="form-group d-flex">
                                    <div class="col-sm-12" style="width: 25%;"></div>
                                    <div class="col-sm-12" style="width: 75%;">
                                        <button class="btn btn-success text-white">যোগ করুন </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
           
                <div class="row">
                    <!-- column -->
                    <div class="col-12  m-auto">
                        <div class="card">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0 text-center">সি. নং</th>
                                            <th class="border-top-0 text-center">আসন </th>
                                            <th class="border-top-0 text-center">থানা</th>
                                            <th class="border-top-0 text-center">ওয়ার্ড </th>
                                            <th class="border-top-0 text-center">পদবি</th>
                                            <th class="border-top-0 text-center">নাম</th>
                                            <th class="border-top-0 text-center">মোবাইল নম্বর</th>
                                            <th class="border-top-0 text-center">ভোটার নং</th>
                                            <th class="border-top-0 text-center">ই-মেইল</th>
                                            <th class="border-top-0 text-center">জন্ম তারিখ</th>
                                            <th class="border-top-0 text-center">ছবি</th>
                                            <th class="border-top-0 text-center">অপারেশন</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data_join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <tr class="tr_n_td">
                                        <!--  -->
                                            
                                            <td><?php echo e($loop->index+1); ?>

                                            </td>
                                            <td><?php echo e($data->name.'-'.$data->no); ?></td>
                                            <td><?php echo e($data->PS_name); ?></td>
                                            <td><?php echo e($data->w_number); ?></td>
                                            <td><?php echo e($data->d_name); ?></td>
                                            <td><?php echo e($data->rp_name); ?></td>
                                            <td><?php echo e($data->rp_phone); ?></td>
                                            <td><?php echo e($data->rp_nid); ?></td>
                                            <td><?php echo e($data->rp_email); ?></td>
                                            <td><?php echo e($data->rp_dob); ?></td>
                                            <td class="td_n_img"><img src="<?php echo e(asset("storage/image/$data->rp_img")); ?>" alt=""></td>
                                            <td class="td_css">
                                            <a  href='/update_page_word_rp/<?php echo e($data->id); ?>' name="btn_edit" class="btn btn-info" style='line-height: 0.5;padding: .5rem'><i class="bi bi-pen"></i></a>
                                            <form class="spacing" method="POST" action='/delete/word_rp/<?php echo e($data->id); ?>'>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button id='custom-btn' class="btn btn-danger" onclick="return confirm('Are you sure??')"> <i class="bi bi-trash"></i> </button>
                                             </form>
                                        </td>
                                        
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
         
       
         <footer class="footer text-center">
           <div class="footer_login">
            All Rights Reserved by <br>
            <a href="http://www.nazmuljewel.com/" target="_blank" style="color:blue; font-size:23px; text-decoration:none;">নাজমুল আলম ভূইয়া জুয়েল </a> <br>
            <span class="footer_span">বিজ্ঞান ও প্রযুক্তি বিষয়ক সম্পাদক</span> <br>
             <a href="https://www.albd-dcn.org/" target="_blank" style="color:green; font-size:23px; text-decoration:red;">ঢাকা মহানগর উত্তর আওয়ামী লীগ</a> 
           </div>
        </footer>
    
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <?php $__env->stopSection(); ?>




<?php $__env->startSection('javaScript'); ?>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script> -->

<script>
    function data_fetch()
            { 
                var p_id =  $('#p_id').val();
                $.ajax({
                    type: "GET",
                    dataType: 'json',
                    url: "/ps_ajax/"+p_id,
                    success:function(respose){
                        var data = '<option>সিলেক্ট থানা</option>';
                        $.each(respose,function(key,value){

                            data = data + '<option value="'+value.id+'">'+value.PS_name+'</option>';
                            
                        });
                        $('#ps_id').html(data);
                    }
                });
                    
            }


            function ps_func(){

                var ps_id =  $('#ps_id').val();
                $.ajax({
                    type: "GET",
                    dataType: 'json',
                    url: "/w_ajax/"+ps_id,
                    success:function(respose){
                        var data = '<option>সিলেক্ট ওয়ার্ড</option>';
                        $.each(respose,function(key,value){

                            data = data + '<option value="'+value.id+'">'+value.w_number+'</option>';
                            
                        });
                        $('#w_id').html(data);
                    }
                });
            }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/alpbd.euitsols.com/public_html/resources/views/word_rp_info.blade.php ENDPATH**/ ?>